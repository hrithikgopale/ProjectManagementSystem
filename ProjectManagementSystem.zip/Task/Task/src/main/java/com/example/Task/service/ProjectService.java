package com.example.Task.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Task.Repository.ProjectRepository;
import com.example.Task.model.Project;

@Service
public class ProjectService {
    @Autowired
	private ProjectRepository projectRepository;
    
    public Project createProject(Project project) {
        return projectRepository.save(project);
    }
    
    // Read
    public List<Project> getAllProjects() {
        return projectRepository.findAll();
    }
    
    public Project getProjectById(Long id) {
        return projectRepository.findById(id).orElse(null);
    }
    
    // Update
    public Project updateProject(Long id, Project projectDetails) {
        Project project = projectRepository.findById(id).orElse(null);
        if (project != null) {
            // Update project details
            // Example: project.setName(projectDetails.getName());
            // Update other fields as needed
            return projectRepository.save(project);
        }
        return null;
    }
    
    // Delete
    public void deleteProject(Long id) {
        projectRepository.deleteById(id);
    }
}
